package com.example.womentr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
